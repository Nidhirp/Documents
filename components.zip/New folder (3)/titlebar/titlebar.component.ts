import { Component } from '@angular/core';

@Component({
  selector: 'app-titlebar',
  templateUrl: './titlebar.component.html',
  styleUrls: ['./titlebar.component.css']
})
export class TitlebarComponent {
 
  private logoimg : string;
  private title : string;
  constructor()
  {
    this.logoimg="../../assets/logo_new.jpg";
    this.title=" NIDHI FOOD PRODUCTS ";
  }

  public get Logo():String{
    return this.logoimg;
  }

  public get Title():String{
    return this.title;
  }


}
