import { Component } from '@angular/core';
import { Restapiservice } from '../restapiservice';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent{
  
  private menus:string[][];
  constructor(private service:Restapiservice) 
  { 

  }

  public get Menus(): string[][]{
    return this.service.getMenus();
  }
}
