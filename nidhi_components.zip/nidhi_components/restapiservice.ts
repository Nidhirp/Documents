export class Restapiservice {
    
    public getMenus() {
        return [["Menu", "/menu"],["Filters", "/filters"],["About Us", "/aboutus"]];
    }

    
}