import { Component } from '@angular/core';
import { Restapiservice } from '../restapiservice';
import {Router} from '@angular/router';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent{
  
  private menus:string[][];
  //private opt:string[][];
  constructor(private service:Restapiservice,
              private _router: Router) 
  { 

  }

  public get Menus(): string[][]{
    return this.service.getMenus();
  }

  /*public get Opt(): string[][]{
    return this.service.getOpt();
  }*/

  public onAccountClick():void{
    this._router.navigate(['/account']);
  }

  public onWishlistClick():void{
    this._router.navigate(['/wishlist']);
  }

  public onCartClick():void{
    this._router.navigate(['/cart']);
  }
}
