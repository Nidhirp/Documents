#include"Headerfile.h"

int main()
{
    char str1[10];
    char str2[10];
    char str3[10];
    char str4[10];
    printf("Enter the question string\n");
    scanf("%s",str1);
    printf("Enter the options\nPlease enter three options\n");
    scanf("%s",str2);
    scanf("%s",str3);
    scanf("%s",str4);
	if (areAnagram(str1, str2))
	{
	printf("They are anagram of each other\n");
	printf("%s\t%s\t",str1,str2);
	}
	else if (areAnagram(str1, str3))
    {
	printf("They are anagram of each other\n");
	printf("%s\t%s\t",str1,str3);
	}
	else if (areAnagram(str1, str4))
	{
	printf("They are anagram of each other\n");
	printf("%s\t%s\t",str1,str4);
	}
	else
	printf("No option possible\n");
	return 0;
}
