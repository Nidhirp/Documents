#ifndef HEADERFILE_H_INCLUDED
#define HEADERFILE_H_INCLUDED
#include <stdio.h>
#include <stdbool.h>
#define NO_OF_CHARS 256
bool areAnagram(char* , char* );


#endif // HEADERFILE_H_INCLUDED
