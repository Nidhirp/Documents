#include"headerfile.h"


int main() {
    int a=0;
    int i=0;
    int b=0;
    printf("Enter the number of Students\n");
    scanf("%d",&a);

    functions(a,b);


}
