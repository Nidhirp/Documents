#include"headerfile.h"
struct student{
    char name[10];
    int grade;
};
int comparator(const void* p, const void* q)
{
    return strcmp(((struct student*)p)->name,
                  ((struct student*)q)->name);
}
void functions(int a, int b)
{
    struct student s[a];
    for(int i=0;i<a;i++)
    {
       printf("Enter the student %d",i+1);
       printf(" details\n");
       printf("Enter name: \n");
       scanf("%s",s[i].name);
       printf("Grades can be either 1 or 2 or 3\n");
       printf("Enter grade: \n");
       scanf("%d",&s[i].grade);
    }int ch;
        printf("Select a option \n1.Show all student details\n2.Show student names\n3.Show student gradewise\n4.Show Sorted Student list\n5.Gradewise Sorted list of students\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1: for(int i=0;i<a;i++)
        {
            printf("%s\t",s[i].name);
            printf("%d\n",s[i].grade);
        }
            break;
        case 2: for(int j=0;j<a;j++)
        {
            printf("%s\n",s[j].name);
        }
            break;
        case 3: printf("Enter the grade of students to be searched\n");
                scanf("%d",&b);
             for(int i=0;i<a;i++)
        {
                if(s[i].grade == 1&&b==1)
                {
                    printf("%s\n",s[i].name);
                }
                else if(s[i].grade == 2&&b==2)
                {
                    printf("%s\n",s[i].name);
                }
                else if(s[i].grade == 3&&b==3)
                {
                    printf("%s\n",s[i].name);
                }
        }
        break;
        case 4: qsort(s, a, sizeof(struct student), comparator);
            for(int i=0;i<a;i++)
        {
            printf("%s\t",s[i].name);
            printf("%d\n",s[i].grade);
        }
            break;
        case 5: printf("Enter the grade of students to be sorted\n");
                scanf("%d",&b);
             for(int i=0;i<a;i++)
        {
                if(s[i].grade == 1&&b==1)
                {
                    qsort(s, a, sizeof(struct student), comparator);
                    printf("%s\n",s[i].name);
                }
                else if(s[i].grade == 2&&b==2)
                {
                    qsort(s, a, sizeof(struct student), comparator);
                    printf("%s\n",s[i].name);
                }
                else if(s[i].grade == 3&&b==3)
                {
                    qsort(s, a, sizeof(struct student), comparator);
                    printf("%s\n",s[i].name);
                }
        }
        default: printf("Invalid choice\n");
    }
}
