#ifndef HEADERFILE_H_INCLUDED
#define HEADERFILE_H_INCLUDED
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void functions(int , int );


#endif // HEADERFILE_H_INCLUDED
