
#include <stdio.h>
#include "rational.h"
#include <math.h>
int main(void)
{
    double n1,d1,n2,d2,n3,d3,n;
    double a,b,c;
    int choice;


    do
    {
        printf("1->add,2->sub,3->mult,4->div,5->absolute,6->positive power,7->negative power,8->floating point power,9->exit");
    printf("Enter a choice: ");
    scanf("%d",&choice);
        switch(choice)
        {
            case 1: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);

                        printf("Enter 2 rational number: \n");
                        printf("Enter a numerator: ");
                        scanf("%d",&n2);
                        printf("Enter a denominator: ");
                        scanf("%d",&d2);
                        add(&n1,&d1,&n2,&d2,&n3,&d3);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
            case 2: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);

                        printf("Enter 2 rational number: \n");
                        printf("Enter a numerator: ");
                        scanf("%d",&n2);
                        printf("Enter a denominator: ");
                        scanf("%d",&d2);
                        sub(&n1,&d1,&n2,&d2,&n3,&d3);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
            case 3: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);

                        printf("Enter 2 rational number: \n");
                        printf("Enter a numerator: ");
                        scanf("%d",&n2);
                        printf("Enter a denominator: ");
                        scanf("%d",&d2);
                        mult(&n1,&d1,&n2,&d2,&n3,&d3);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
            case 4: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);

                        printf("Enter 2 rational number: \n");
                        printf("Enter a numerator: ");
                        scanf("%d",&n2);
                        printf("Enter a denominator: ");
                        scanf("%d",&d2);
                        div(&n1,&d1,&n2,&d2,&n3,&d3);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
            case 5: {
                        printf("Enter rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);
                        abso(&n1,&d1,&n3,&d3);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
            case 6: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);
                        printf("Enter a positive power: ");
                        scanf("%d",&n);
                        expop(&n1,&d1,&n3,&d3,&n);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
             case 7: {
                        printf("Enter 1 rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%d",&n1);
                        printf("Enter a denominator: ");
                        scanf("%d",&d1);
                        printf("Enter a positive power: ");
                        scanf("%d",&n);
                        expon(&n1,&d1,&n3,&d3,&n);
                        printf("%d/%d \n",n3,d3);
                        break;
                    }
             case 8: {
                        printf("Enter rational number:\n ");
                        printf("Enter a numerator: ");
                        scanf("%lf",&n1);
                        printf("Enter a denominator: ");
                        scanf("%lf",&d1);
                        printf("Enter a float power: ");
                        scanf("%lf",&n);
                        expof(&n1,&d1,&n3,&d3,&n);
                        printf("%lf/%lf \n",n3,d3);
                        break;
                    }
            case 9: break;
        }
    }while(choice!=9);


    return 0;
}

