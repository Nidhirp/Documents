#ifndef RATIONAL_H_INCLUDED
#define RATIONAL_H_INCLUDED

             void display(int n,int d)
            {
                        printf("Result is : %d/%d",n,d);
            }

             void add(int* n1, int* d1,int* n2, int* d2,int* n3, int* d3)
            {
                        *n3 = *n1*(*d2) + *d1*(*n2);
                        *d3 = *d1*(*d2);
                        hcf(n3,d3);
                        printf("addition completed:");
            }
             void sub(int* n1, int* d1,int* n2, int* d2,int* n3, int* d3)
            {
                        *n3 = *n1*(*d2) - *d1*(*n2);
                        *d3 = *d1*(*d2);
                         hcf(n3,d3);
                        printf("subtraction completed:");
            }
             void mult(int* n1, int* d1,int* n2, int* d2,int* n3, int* d3)
            {
                        *n3 = *n1*(*n2);
                        *d3 = *d1*(*d2);
                        hcf(n3,d3);
                        printf("multiplication completed:");
            }
             void div(int* n1, int* d1,int* n2, int* d2,int* n3, int* d3)
            {
                        *n3 = *n1*(*d2);
                        *d3 = *d1*(*n2);
                        hcf(n3,d3);
                        printf("division completed:");
            }
            void abso(int* n1,int* d1,int* n3,int* d3)
            {
                if(*n1<0)
                *n3=-(*n1);
                else
                    *n3=*n1;
                if(*d1<0)
                *d3=-(*d1);
                 else
                    *d3=*d1;
                printf("absolute completed:");
            }
             void expop(int* n1,int* d1,int* n3,int* d3,int* n)
            {
                if(*n==0)
                {
                    *n3=1;
                    *d3=1;
                }
                else
                {

                for(int i=0;i<*n;i++)
                {
                    *n3=*n1*(*n1);
                }
               for(int i=0;i<*n;i++)
                {
                    *d3=*d1*(*d1);
                }
                }
                printf("expop completed:");
            }
            void expon(int* n1,int* d1,int* n3,int* d3,int* n)
            {
                if(*n==0)
                {
                    *n3=1;
                    *d3=1;
                }
                else
                {
                    *n=-(*n);
                for(int i=0;i<*n;i++)
                {
                    *n3=*n1*(*n1);
                }
               for(int i=0;i<*n;i++)
                {
                    *d3=*d1*(*d1);
                }
              int tmp;
              tmp=*n3;
              *n3=*d3;
              *d3=tmp;
                }
                printf("expop completed:");
            }
            void expof(double* n1,double* d1,double* n3,double* d3,double* n)
            {
                if(*n==0)
                {
                    *n3=1;
                    *d3=1;
                }
                else
                {

                    *n3=pow(*n1,*n);
                    *d3=pow(*d1,*n);
                }
                printf("expo f completed:");
            }
            int hcf(int* num,int* den)
            {
                        int a,b,c;
                        a = *num;
                        b = *den;
                        do
                        {
                                    c = a%b;
                                    a = b;
                                    b = c;
                        }
                        while(c != 0);
                        *num = *num/a;
                        *den = *den/a;
            }


#endif // RATIONAL_H_INCLUDED
