#ifndef HEADERFILE_H_INCLUDED
#define HEADERFILE_H_INCLUDED
#include<stdio.h>
int binarySearch(int [] , int ,int , int );


#endif // HEADERFILE_H_INCLUDED
