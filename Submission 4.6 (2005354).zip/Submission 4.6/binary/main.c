#include "headerfile.h"

int main(void)
{
    int n=0;
    int x=0;
    printf("Enter the size of array\n");
    scanf("%d",&n);
	int arr[n];
	printf("Enter the sorted array\n");
	for(int i=0;i<n;i++)
	{
	    scanf("%d",&arr[i]);
	}
	printf("Enter the element to be searched\n");
	scanf("%d",&x);
	int result = binarySearch(arr, 0, n - 1, x);
	(result == -1) ? printf("Element is not present in array")
				: printf("Element is present at index %d",
							result);
	return 0;
}
